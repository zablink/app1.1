// pages/unauthorized.tsx
export default function Unauthorized() {
  return (
    <div className="min-h-screen flex items-center justify-center text-red-600 text-xl font-bold">
      คุณไม่มีสิทธิ์เข้าถึงหน้านี้
    </div>
  );
}
