// /src/middleware.ts

import { getToken } from "next-auth/jwt";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export async function middleware(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });
  const url = req.nextUrl.clone();
  const pathname = req.nextUrl.pathname;

  const isApiRoute = pathname.startsWith("/api");
  const isStaticAsset =
    pathname.startsWith("/_next") ||
    pathname.startsWith('/images') ||
    pathname === "/favicon.ico" ||
    pathname === "/robots.txt" ||
    pathname.endsWith(".png") ||
    pathname.endsWith(".jpg") ||
    pathname.endsWith(".css") ||
    pathname.endsWith(".woff2") ||
    pathname.endsWith(".ttf") ||
    pathname.endsWith(".otf");

  const isPublicRoute = [
    "/", // ✅ เพิ่ม '/' ให้เปิดได้เสมอ
    "/login",
    "/complete-profile",
  ];

  // ✅ CHECK login required
  /* Comment for not redirect every pages to LOGIN
  if (
    !token &&
    !isApiRoute &&
    !isStaticAsset &&
    !isPublicRoute.includes(pathname)
  ) {
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
  */

  // ✅ BLOCK user เข้า store/admin
  if (token?.role === "user" && (pathname.startsWith("/store") || pathname.startsWith("/admin"))) {
    url.pathname = "/unauthorized";
    return NextResponse.redirect(url);
  }

  // ✅ BLOCK store เข้า admin
  if (token?.role === "store" && pathname.startsWith("/admin")) {
    url.pathname = "/unauthorized";
    return NextResponse.redirect(url);
  }

  // ✅ BLOCK admin เข้า store
  if (token?.role === "admin" && pathname.startsWith("/store")) {
    url.pathname = "/unauthorized";
    return NextResponse.redirect(url);
  }

  // ✅ user ต้องกรอก complete-profile ก่อน
  /*
  if (
    token?.role === "user" &&
    pathname !== "/complete-profile" &&
    pathname !== "/login" &&
    pathname !== "/" && // ✅ ให้เข้า home ได้
    !pathname.startsWith("/api/check-profile")
  ) {
    
    const checkProfile = await fetch(`${req.nextUrl.origin}/api/check-profile`, {
      headers: {
        cookie: req.headers.get("cookie") ?? "",
      },
    });

    if (checkProfile.status === 200) {
      const { isComplete } = await checkProfile.json();
      console.log("Check profile returned isComplete =", isComplete); // 🔍 ดูผลตรงนี้
      if (!isComplete) {
        console.log("Redirecting to /complete-profile");
        url.pathname = "/complete-profile";
        return NextResponse.redirect(url);
      }
    } else {
      console.log("Check profile failed. Redirecting to /complete-profile");
      url.pathname = '/complete-profile';
      return NextResponse.redirect(url);
    }
  }*/

  const res = NextResponse.next();
  res.headers.set("Cache-Control", "no-store");
  return res;

}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|robots.txt).*)",
  ],
};
